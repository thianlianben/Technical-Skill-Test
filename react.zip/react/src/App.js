import React,{ Component } from 'react';
import './App.css';
import { BrowserRouter as Router , Route } from 'react-router-dom';
import AppBarLayout from './Layouts/AppBarLayout';
import Home from './Layouts/Home';
import uuid from 'uuid';

class App extends Component {
  state={
    product:[
        { id : uuid.v4(),name : 'Coombes',info : 'LOUNGE',price : '$2,600' , img:'./public/2.jpg'},
        { id : uuid.v4(),name : 'Keeve Set', info : 'TABLES & CHAIRS',price : '$590' , img:'../../public/2.jpg'},
        { id : uuid.v4(),name : 'NIILE',info : 'ARMCHAIR',price : '$950',img:'../../public/2.jpg'},
        { id : uuid.v4(),name : 'Blanko',info : 'SIDE TABLE',price : '$2,600',img:'../../public/2.jpg'},
        { id : uuid.v4(),name : 'Momo',info : 'SHELVES',price : '$2,600',img:'../../public/2.jpg'},
        { id : uuid.v4(),name : 'Penemille',info : 'CHAIR',price : '$2,600',img:'../../public/2.jpg'},
        { id : uuid.v4(),name : 'Coombes',info : 'LOUNGE',price : '$2,600',img:'../../public/2.jpg'}
    ]
}
  render(){
    return (
      <Router>
        <div className="App">
          <AppBarLayout/>
          <br/>
          <br/>
          <br/>
          <Route exact path="/" render={ props=>(
            <React.Fragment>
              <Home products={this.state.product}/>
            </React.Fragment>
          )}/>
        </div>
      </Router>
    );
  }
}

export default App;
