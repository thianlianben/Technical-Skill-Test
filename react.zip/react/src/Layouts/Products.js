import React,{ Component } from 'react';
import Grid from '@material-ui/core/Grid';
import './style.css';
import Select from '@material-ui/core/Select';
import LocalGroceryStoreOutlinedIcon from '@material-ui/icons/LocalGroceryStoreOutlined';
import Rating from '@material-ui/lab/Rating';
import StarBorderIcon from '@material-ui/icons/StarBorder';
import Sliders from './Slider';

class Products extends Component{
    render(){
        const a = {
            color: 'black',
            float: 'left',
            padding: '8px 16px',
            textDecoration: 'none'
        }
        const imageStyle = {
            width:'100%',
            height : '80%'
        }
        const productDataStyle = {
            fontSize : '18px', paddingLeft:'15px', paddingTop:'8px',width : '100%'
        }
        return (
            <div style={{ background : 'white'}}>
                <Grid container spacing={3} style={{ textAlign : 'left' }}>
                    <Grid item xs={12} md={5} lg={3}>
                        <br/>
                        <div>Filter By</div>
                        <br/>
                        <div>
                            <Select fullWidth native>
                                <option selected>Collection</option>
                                <option>Ten</option>
                                <option>NIne</option>
                            </Select>
                            </div>
                            <br/>
                            <div>
                            <Select fullWidth native>
                                <option selected>Color</option>
                                <option>Ten</option>
                                <option>NIne</option>
                            </Select>
                            </div>
                            <br/>
                            <div>
                            <Select fullWidth native>
                                <option selected>Category</option>
                                <option>Ten</option>
                                <option>NIne</option>
                            </Select>
                            <br/>
                        </div>
                        <br/>
                        <Sliders/>
                    </Grid>
                    {
                        this.props.products.map(
                            (p)=>(
                                <Grid item xs={12} md={5} lg={3}>
                                    <img src='https://mdbootstrap.com/img/Mockups/Lightbox/Thumbnail/img%20(67).jpg' style={imageStyle} alt={p.name}/>
                                    <div class="row" style={productDataStyle}>
                                        <div style={{ width:'30%'}}>
                                            <div>
                                                {p.name}
                                            </div>
                                            <div style={{ color:'#ABB2B9',fontSize : '10px' ,paddingBottom:'3px' }}>
                                                { p.info }
                                            </div>
                                            <div>
                                                <Rating
                                                    name="customized-empty"
                                                    value={5}
                                                    size="small"
                                                    precision={0.5}
                                                    emptyIcon={<StarBorderIcon fontSize="10px" />}
                                                    />
                                            </div>
                                        </div>
                                        <div style={{ textAlign : 'right',width:'70%' }}>
                                            <div style={{ color:'#ABB2B9', fontSize : '15px' }}>
                                                {p.price}
                                            </div>
                                            <div>
                                                <LocalGroceryStoreOutlinedIcon fontSize="large"/>
                                            </div>
                                        </div>
                                    </div>
                                </Grid>
                            )
                        )
                    }
                </Grid>
                <br/>
                <br/>
                <div style={{ textAlign : 'left'}}>
                    <div class="pagination">
                        <a href="#">1</a>
                        <a href="#" class="active">2</a>
                        <a href="#">3</a>
                        <a href="#">4</a>
                        <a href="#">5</a>
                        <a href="#">6</a>
                        <a href="#">7</a>
                        <a href="#">8</a>
                        <a href="#">9</a>
                        <a href="#">10</a>
                        <a href="#">&raquo;</a>
                    </div>
                </div>
            </div>
        )
        
    }
    
}

export default Products;
