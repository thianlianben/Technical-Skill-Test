import React, { Component } from 'react'
import Grid from '@material-ui/core/Grid';
import Products from './Products';
import Select from '@material-ui/core/Select';
import TextField from '@material-ui/core/TextField';
import SearchIcon from '@material-ui/icons/Search';

export class Home extends Component {
    render() {
        return (
            <div style={{ margin : '20px', background :'white'}}>
                <div>
                <Grid container spacing={2} >
                    <Grid item >
                        <SearchIcon fontSize="large"/>
                    </Grid>
                    <Grid item xs={10} md={8} lg={9}>
                        <TextField  fullWidth/>
                    </Grid>
                    <Grid item xs={12} md={3} lg={2}>
                        <Select fullWidth native>
                            <option selected>Best Match</option>
                            <option>Ten</option>
                            <option>NIne</option>
                        </Select>
                    </Grid>
                </Grid>
                </div>
                <br/>
                <Products products={this.props.products}/>
            </div>
        )
    }
}

export default Home
